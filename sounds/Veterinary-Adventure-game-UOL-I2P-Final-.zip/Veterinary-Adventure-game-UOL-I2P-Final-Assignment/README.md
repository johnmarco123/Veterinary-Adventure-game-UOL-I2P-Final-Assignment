Welcome to my game!

The game consists of five levels and has four difficulties.

peaceful - infinite lives (suggested if your testing/evaluating the games mechanics and levels)
Easy - 10 lives
Medium - 3 lives
Hard - 1 life

Please note there are two versions of this game and the only differences between the two are that one is soundless, and one has sound. The soundless version can be run directly in the browser, whilst the one with sound MUST BE LOCALLY HOSTED. There is no need to run the soundless version unless you cannot locally host the main game, therefore do not worry about checking over both files to grade this assignment.

Enjoy the game.
